package med.voll.api.domain.DTO.paciente;

import med.voll.api.domain.DTO.paciente.DadosPaciente;
import med.voll.api.domain.entity.Endereco;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class DadosPacienteTest {

    @Test
    void testGetters() {

        Endereco enderecoMock = mock(Endereco.class);

        DadosPaciente dadosPaciente = new DadosPaciente("Josué", "josue@gmail.com", "123456789", "123.456.789-00", enderecoMock);

        assertEquals("Josué", dadosPaciente.nome());
        assertEquals("josue@gmail.com", dadosPaciente.email());
        assertEquals("123456789", dadosPaciente.telefone());
        assertEquals("123.456.789-00", dadosPaciente.cpf());
        assertEquals(enderecoMock, dadosPaciente.endereco());
    }

    @Test
    void testRecordEquals() {

        Endereco endereco1 = new Endereco("Rua endaiatuba", "Vila monte alegre", "12345", "São Paulo", "SP", "Próximo a ubs", "123");
        Endereco endereco2 = new Endereco("Rua general montes", "Vila guarani", "54321", "Rio de Janeiro", "RJ", "Próximo ao mercado", "321");

        DadosPaciente paciente1 = new DadosPaciente("Mauro Cezar", "MauroCezar@gmail.com", "123456789", "123.456.789-00", endereco1);
        DadosPaciente paciente2 = new DadosPaciente("Luciana Moraes", "LucianaMoraes@gmail.com", "987654321", "987.654.321-00", endereco2);

        assertNotEquals(paciente1, paciente2);

        DadosPaciente paciente3 = new DadosPaciente("Mauro Cezar", "MauroCezar@gmail.com", "123456789", "123.456.789-00", endereco1);

        assertEquals(paciente1, paciente3);
    }
}

package med.voll.api.domain.DTO.medico;


import med.voll.api.domain.entity.Medico;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class DadosListagemMedicoTest {

    @Test
    void testDadosListagemMedico() {

        Long id = 1L;
        String nome = "João";
        String email = "joao@gmail.com";
        String crm = "123ABC";
        Especialidade especialidade = Especialidade.CARDIOLOGIA;


        Medico medicoMock = mock(Medico.class);

        when(medicoMock.getId()).thenReturn(id);
        when(medicoMock.getNome()).thenReturn(nome);
        when(medicoMock.getEmail()).thenReturn(email);
        when(medicoMock.getCrm()).thenReturn(crm);
        when(medicoMock.getEspecialidade()).thenReturn(especialidade);


        DadosListagemMedico dadosListagemMedico = new DadosListagemMedico(medicoMock);


        assertEquals(id, dadosListagemMedico.getId());
        assertEquals(nome, dadosListagemMedico.getNome());
        assertEquals(email, dadosListagemMedico.getEmail());
        assertEquals(crm, dadosListagemMedico.getCrm());
        assertEquals(especialidade, dadosListagemMedico.getEspecialidade());
    }
}

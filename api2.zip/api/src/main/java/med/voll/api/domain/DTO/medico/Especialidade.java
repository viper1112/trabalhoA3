package med.voll.api.domain.DTO.medico;

public enum Especialidade {
    ORTOPEDIA, CARDIOLOGIA, GINECOLOGIA, DERMATOLOGIA;
}

package med.voll.api.service;

import java.util.List;
import java.util.Set;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import lombok.Getter;
import lombok.Setter;
import med.voll.api.domain.DTO.consulta.DadosAgendamentoConsulta;
import med.voll.api.domain.DTO.consulta.DadosCancelamentoConsulta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import med.voll.api.domain.entity.Medico;
import med.voll.api.domain.entity.Paciente;
import med.voll.api.domain.entity.Pagar;
import med.voll.api.infra.exceptions.ValidacaoException;
import med.voll.api.repository.ConsultaRepository;
import med.voll.api.repository.MedicoRepository;
import med.voll.api.repository.PacienteRepository;
import med.voll.api.validation.consulta.cancelar.ValidadorCancelamentoDeConsulta;

@Service
// OCP - Princípio do aberto/fechado e SRP - Princípio da responsabilidade única
interface Pagamento {


    void Pagar (DadosAgendamentoConsulta dados, double valorConsulta);
    void Validar (DadosCancelamentoConsulta dados);
}

class ConcreteCreditCardPayment extends CreditCardPayment {
    @Override
    public void Validar(DadosCancelamentoConsulta dados) {
    }

}
@Component
abstract class CreditCardPayment implements Pagamento {
    private final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
    private final Validator validator = factory.getValidator();

    @Autowired
    private PacienteRepository pacienteRepository;

    @Autowired
    private MedicoRepository medicoRepository;

    @Autowired
    private List<ValidadorCancelamentoDeConsulta> validadoresCancelamento;


    @Autowired
    private ConsultaRepository consultaRepository;

    CreditCardPayment() {
    }

    public void validar(DadosCancelamentoConsulta dados) {

        if (!consultaRepository.existsById(dados.getIdConsulta())) {throw new ValidacaoException("Id da consulta informado não existe!");
        }

        var consulta = consultaRepository.getReferenceById(dados.getIdConsulta());
        if (consulta == null) {throw new ValidacaoException("Consulta não encontrada para o ID fornecido");
        }

        validadoresCancelamento.forEach(v -> v.validar(dados));
        consulta.cancelar(dados.getMotivo());
    }

    @Override
    public void Pagar(DadosAgendamentoConsulta dados, double valorConsulta) {
        Paciente paciente = pacienteRepository.findById(dados.getIdPaciente()).get();
        Medico medico = medicoRepository.findById(dados.getIdMedico()).get();
        Pagar pagamento = new Pagar(paciente.getNome(), medico.getNome(), dados.getData(), valorConsulta);
    }

    public void setValidadoresCancelamento(List<ValidadorCancelamentoDeConsulta> validadoresCancelamento) {
    }

    public void setConsultaRepository(ConsultaRepository consultaRepository) {
    }
}







